<?php

namespace App\Controllers;

use App\Controllers\BaseController;

class ControllerMasyarakat extends BaseController
{
    public function index()
    {
        //
    }
}
