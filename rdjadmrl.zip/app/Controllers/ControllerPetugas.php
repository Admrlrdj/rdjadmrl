<?php

namespace App\Controllers;

use App\Controllers\BaseController;

class ControllerPetugas extends BaseController
{
    public function index()
    {
        //
    }
}
